import 'package:flutter/material.dart';
import 'signupCiv.dart';
import 'signupCT.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: signup(),
    );
  }
}

class signup extends StatefulWidget {
  @override
  _signupState createState() => _signupState();
}

class _signupState extends State<signup> {
  List<ListItem> _dropdownItems = [
    ListItem(1, "Civilian"),
    ListItem(2, "Contact Tracer")
  ];

  List<DropdownMenuItem<ListItem>> _dropdownMenuItems;
  ListItem _selectedItem;

  void initState() {
    super.initState();
    _dropdownMenuItems = buildDropDownMenuItems(_dropdownItems);
    _selectedItem = _dropdownMenuItems[0].value;
  }

  List<DropdownMenuItem<ListItem>> buildDropDownMenuItems(List listItems) {
    List<DropdownMenuItem<ListItem>> items = List();
    for (ListItem listItem in listItems) {
      items.add(
        DropdownMenuItem(
          child: Text(listItem.name),
          value: listItem,
        ),
      );
    }
    return items;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Registration Page"),
        backgroundColor: const Color(4281608744),
      ),
      body: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 60.0),
            child: Center(
              child: Container(
                  width: 200,
                  height: 150,
                  /*decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(50.0)),*/
                  child: Image.asset('asset/images/logo.png')),
            ),
          ),
          Text('Select User Type:'),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: const EdgeInsets.only(left: 10.0,right: 10.0),
              decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all()),
              child: DropdownButtonHideUnderline(
                child: DropdownButton(
                    value: _selectedItem,
                    items: _dropdownMenuItems,
                    onChanged: (value) {
                      setState(() {
                        _selectedItem = value;
                      });
                    }),
              ),
            ),
          ),
          Text("You select ${_selectedItem.name}"),
          Container(
            height: 50,
            width: 250,
            decoration: BoxDecoration(
                color: const Color(4281608744), borderRadius: BorderRadius.circular(20)),
            child: FlatButton(
              onPressed: () {
                if ( _selectedItem.name == "Civilian") {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => signupCiv()));
                  print("Civilian Registration Form");
                } else {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => signupCT()));
                  print("Contact Tracer Registration Form");
                }
              },
              child: Text(
                'Next',
                style: TextStyle(color: Colors.white, fontSize: 25),
              ),
            ),
          ),        ],
      ),
    );
  }
}

class ListItem {
  int value;
  String name;

  ListItem(this.value, this.name);
}